import os
import random
if __name__=="__main__":
    imagepath="/data/wangtao/JapDigit/20170103/"
    listpath = "./"
    trainlist = "train_sub_list.txt"
    testlist = "test_sub_list.txt"
    codelist = "code_sub_list.txt"
    trainlistfile = open(listpath+trainlist, "w")
    testlistfile = open(listpath+testlist, "w")
    codelistfile = open(listpath+codelist, "w")
    codenamelist = ["0","1", "2", "3" , "4" , "5" , "6" , "7" , "8" , "9" , "10","11", "neg"]
    n = 0
#    for name in os.listdir(imagepath):
    for name in codenamelist:
        dirlist = os.listdir(imagepath+name+"/")
        random.shuffle(dirlist)
        imageno = len(dirlist)
        imageno09 = imageno*0.9
        codelistfile.write(name + " " + str(n)+"\n")
        nn = 0
        for imagename in dirlist:
            if nn < imageno09:
                trainlistfile.write(name+"/"+imagename + " "+ str(n)+"\n")
            else:
                testlistfile.write(name+"/"+imagename + " "+ str(n)+"\n")
            nn = nn + 1
        n = n+1
    trainlistfile.close()
    testlistfile.close()
    codelistfile.close()

