#! /bin/bash

caffepath="/home/wangtao/caffe_tool/CaffeGitM/build/"

export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=${caffepath}lib:$LD_LIBRARY_PATH
# nccl path
export LD_LIBRARY_PATH=/home/wangtao/caffe_official/nccl/build/lib:$LD_LIBRARY_PATH   




################ Step 1a ###################
### convert imageset: training set
${caffepath}tools/convert_imageset \
        --backend=lmdb \
        --gray=true \
        /data/wangtao/JapDigit/20170103/ \
        data/train_sub_list.txt \
        data/train_lmdb

################ Step 1b ###################
### convert imageset: test set
${caffepath}tools/convert_imageset \
        --backend=lmdb \
        --gray=true \
        /data/wangtao/JapDigit/20170103/ \
        data/test_sub_list.txt \
        data/test_lmdb

cd ${caffepath}.. && make all -j && cd -

### train a cnn model
${caffepath}tools/caffe train \
    --solver=config/solver.prototxt \
    --gpu=0,1,2,3 \
    2>&1 | tee info.txt
